#ifndef _PASS4_H_
#define _PASS4_H_

void pass4_fix_block_bitmap(fsck_info_t* fsck_info);
void init_local_blkmap(fsck_info_t *fsck_info, int total);

#endif /* !_PASS4_H_ */