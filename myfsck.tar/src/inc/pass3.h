#ifndef _PASS3_H_
#define _PASS3_H_

void pass3_fix_link_count(fsck_info_t *fsck_info);

#endif /* !_PASS3_H_ */