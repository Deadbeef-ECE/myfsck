/* @file: pass3.h
 *
 * @breif: Functions for myfsck pass3
 *
 * @author: Yuhang Jiang (yuhangj@andrew.cmu.edu)
 * @bug: No known bugs
 */

#ifndef _PASS3_H_
#define _PASS3_H_

void pass3_fix_link_count(fsck_info_t *fsck_info);

#endif /* !_PASS3_H_ */
